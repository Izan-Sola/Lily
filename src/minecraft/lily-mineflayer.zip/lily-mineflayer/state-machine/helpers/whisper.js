import { Logger } from "../../../../utils/Logger.js"

/**
 * WHISPER / PRIVATE MESSAGE SUPPORT
 * ─────────────────────────────────────────────────────────────────────────────
 * mineflayer already tries to detect vanilla-style whispers and fires a
 * built-in `whisper` event (username, message). That covers vanilla /tell
 * and a handful of common formats out of the box.
 *
 * Plugin servers (EssentialsX, etc.) often format /msg differently, e.g.:
 *   [Player -> me] hello
 *   [Player -> You] hello
 *   Player -> Me: hello
 *   Player whispers to you: hello
 *   From Player: hello
 *   [Player -> Lily] hello        (some plugins put the recipient name)
 *
 * These extra patterns are matched here as a fallback against the raw
 * chat line, in case the built-in `whisper` event doesn't fire for your
 * server's plugin. Add more patterns to WHISPER_PATTERNS if your server
 * uses something different — check the raw chat line with a quick
 * `bot.on('message', m => console.log(JSON.stringify(m.toString())))`.
 */
const WHISPER_PATTERNS = [
    /^\[(.+?)\s*(?:->|→)\s*(?:me|you|Me|You)\]\s*(.*)$/,
    /^(.+?)\s*(?:->|→)\s*(?:me|Me)\s*:\s*(.*)$/,
    /^(.+?) whispers(?: to you)?:\s*(.*)$/i,
    /^From (.+?):\s*(.*)$/i,
    /^\* (.+?) -> Me \*\s*(.*)$/i,
]

export function parseWhisperLine(rawText) {
    const text = rawText.trim()
    for (const pattern of WHISPER_PATTERNS) {
        const m = text.match(pattern)
        if (m) return { from: m[1].trim(), message: m[2].trim() }
    }
    return null
}

/**
 * Wires up whisper detection on the bot. Calls onWhisper(username, message)
 * whenever a private message comes in, from either the built-in event or
 * the fallback regex match — deduped so the same line never fires twice.
 */
export function attachWhisperListener(bot, onWhisper) {
    let lastSeen = { key: null, at: 0 }

    const dedupeFire = (username, message) => {
        const key = `${username}:${message}`
        const now = Date.now()
        if (lastSeen.key === key && now - lastSeen.at < 500) return // same line via both paths
        lastSeen = { key, at: now }
        onWhisper(username, message)
    }

    // Primary: mineflayer's own whisper detection
    bot.on('whisper', (username, message) => {
        if (!username || username.toLowerCase() === bot.username.toLowerCase()) return
        dedupeFire(username, message)
    })

    // Fallback: raw chat line, for server/plugin-specific /msg formats
    bot.on('message', (jsonMsg) => {
        const text = jsonMsg.toString()
        const parsed = parseWhisperLine(text)
        if (!parsed) return
        if (parsed.from.toLowerCase() === bot.username.toLowerCase()) return
        dedupeFire(parsed.from, parsed.message)
    })
}

/**
 * Sends a private reply the same way the person messaged in — via /msg —
 * so it doesn't spam public chat. Splits long replies into multiple /msg
 * lines the same way mcChat does for public chat.
 */
export function mcWhisper(bot, username, message, limit = 250) {
    _splitMessage(message, limit).forEach(chunk => {
        bot.chat(`/msg ${username} ${chunk}`)
    })
    Logger.info(`→ ${username}: ${message}`, "WHISPER")
}

function _splitMessage(text, limit = 250) {
    const words = text.split(" ")
    const chunks = []
    let current = ""
    for (const word of words) {
        if ((current + " " + word).trim().length > limit) {
            if (current) chunks.push(current.trim())
            current = word
        } else {
            current = current ? current + " " + word : word
        }
    }
    if (current) chunks.push(current.trim())
    return chunks
}
