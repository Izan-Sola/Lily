import pkg from "discord.js"
const { REST, Routes } = pkg
import fs from "fs"
import path from "path"
import { fileURLToPath } from "url"
import { config } from "../utils/config.js"
import { Logger } from "../utils/Logger.js"
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const deploy = async () => {
    const commandsPath = path.join(__dirname, "/commands")
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith(".js"))
    const commands = []

    for (const file of commandFiles) {
        const command = await import(`./commands/${file}`)
        commands.push(command.data.toJSON())
        Logger.info(`Loaded command: ${command.data.name}`, "SLASH COMMANDS")
    }

    const rest = new REST({ version: "10" }).setToken(config.token)

    try {
        await rest.put(
            Routes.applicationCommands(config.clientId),
            { body: commands }
        )
        Logger.success("Slash commands deployed successfully!", "SLASH COMMANDS")
    } catch (error) {
        Logger.error("Error deploying slash commands: " + error.message, "SLASH COMMANDS")
        throw error
    }
}

export default deploy


if (import.meta.url === `file://${process.argv[1]}`) {
    deploy()
}